# tests/test_demo.py
def test_demo():
    assert True